hexbin
======
[![Build Status](https://travis-ci.org/edzer/hexbin.png?branch=master)](https://travis-ci.org/edzer/hexbin)

An R Package with binning and plotting functions for hexagonal bins.
